library(writexl)
library(ggplot2)
library(readr)
library(tidyverse)
library(dplyr)
library(ratdat)
library(scales)
library(agridat)
library(lme4)


banco_de_dados <- read.csv("sempc/data_raw/dt.csv")
view(banco_de_dados)

banco_de_dados <- banco_de_dados %>%
  mutate(publication = as.factor(paste(author, year)))%>%
  filter(!is.na(new_analitical_method)) %>%
  filter(!is.na(new_detection_method)) %>%
  filter(!is.na(new_environment)) %>%
  filter(!is.na(method)) %>%
  filter(!is.na(D)) %>%
  select(publication, family, species, genus, D, Log10.D, SE, new_detection_method, new_analitical_method, method, bodymass_g_pantheria, new_environment, Lat, Long, Altitude, annual_precipitation, sampling_effort, country)
view(banco_de_dados)

with(banco_de_dados, tapply(D, list(new_detection_method, new_analitical_method), length))
table(banco_de_dados$method)

banco_de_dados$method <- as.factor(banco_de_dados$method)
banco_de_dados$new_environment <- as.factor(banco_de_dados$new_environment)
banco_de_dados$new_analitical_method <- as.factor(banco_de_dados$Lat)
banco_de_dados$new_detection_method <- as.factor(banco_de_dados$Altitude)
banco_de_dados$new_analitical_method <- as.factor(banco_de_dados$annual_precipitation)
banco_de_dados$logmass_kg <- log(banco_de_dados$bodymass_g_pantheria/1000)
banco_de_dados$sqrt_rainfall <- sqrt(banco_de_dados$annual_precipitation)
banco_de_dados$log_Lat <- scale(log(abs(banco_de_dados$Lat)))
banco_de_dados$log_Altitude <- scale(log(banco_de_dados$Altitude))

# LM

t <- lm(log(D) ~ method + family +
          logmass_kg + new_environment +
          log(abs(Lat)) + log(Altitude) + 
          sqrt_rainfall + I(sqrt_rainfall^2), 
        data = banco_de_dados)
summary(t1)

t1 <- lmer(log(D) ~ method + family + 
                logmass_kg + new_environment + 
                log(abs(Lat)) + log(Altitude) + 
                sqrt_rainfall + I(sqrt_rainfall^2) + 
                (1 | species), 
              data = banco_de_dados, REML = FALSE)


t2 <- lm(log(D) ~ method + family +
          logmass_kg + new_environment +
          log(abs(Lat)) + log(Altitude) + 
          sqrt_rainfall + I(sqrt_rainfall^2), 
        data = banco_de_dados)
summary(t1)
plot(t1)


AIC(t,tlmm0)

# LMM

tlmm0 <- lmer(log(D) ~ family + method +
            logmass_kg + new_environment +
            log_Lat + log_Altitude + 
            sqrt_rainfall + I(sqrt_rainfall^2) + 
            (1|species) +  (1|family) + (1|publication), 
          data = banco_de_dados)
summary(tlmm0)
plot(tlmm0)

we <- AIC(tlmm0)
wf <- AIC(tlmm0)
wm <- AIC(tlmm0)
wb <- AIC(tlmm0)
wr <- AIC(tlmm0)
wl <- AIC(tlmm0)
wa <- AIC(tlmm0)
full_model <- AIC(tlmm0)

aics <- c(full = full_model, env = we, fam = wf, met = wm, bdmass = wb, rnfll = wr, lat = wl, altitude = wa)
(daics <- aics - min(aics))

anova(t1, tlmm0)

nd <- data.frame(family = "Cervidae",
                 method = unique(banco_de_dados$method),
                 logmass_kg = mean(banco_de_dados$logmass_kg),
                 new_environment = "Dense Forest",
                 log_Lat = mean(banco_de_dados$log_Lat),
                 log_Altitude = mean(banco_de_dados$log_Altitude),
                 sqrt_rainfall = mean(banco_de_dados$sqrt_rainfall))
method_predictions <- tlmm0 %>%
  predict(newdata=nd, se.fit=TRUE, re.form=NA) %>%
  as.data.frame() %>%
  mutate(prdn = exp(fit),
         lcl = exp(fit-1.96*se.fit),
         ucl = exp(fit+1.96*se.fit)) %>%
  cbind(nd)

method_predictions <- data.frame(prdn = exp(method_predictions$fit),
                                 lcl = )

write_xlsx(banco_de_dados, "sempc/data/banco_de_dados.xlsx")
