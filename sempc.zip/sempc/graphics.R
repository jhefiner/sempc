# Graphics

d_methods<-ggplot(banco_de_dados, aes(x = method, y = log(D))) +
  geom_boxplot(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Methods", y = "Density") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

d_environments <- ggplot(banco_de_dados, aes(x = new_environment, y = log(D))) +
  geom_boxplot(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Environments", y = "Density") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

d_family <- ggplot(banco_de_dados, aes(x = family, y = log(D))) +
  geom_boxplot(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Families", y = "Density (Log-transformed values)") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X


# Calcular as contagens de cada espécie
cnt_species <- banco_de_dados %>%
  group_by(species) %>%
  summarise(Quantidade = n()) %>%
  arrange(desc(Quantidade))  # Ordenar em ordem decrescente

# Criar o gráfico de barras usando os dados contados
qt_species <- ggplot(cnt_species, aes(x = reorder(species, -Quantidade), y = Quantidade)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black") +  # gráfico de barras com contagem
  labs(x = "Species", y = "Number of Estimates") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

cnt_genus <- banco_de_dados %>%
  group_by(genus) %>%
  summarise(Quantidade = n()) %>%
  arrange(desc(Quantidade))  # Ordenar em ordem decrescente

# Criar o gráfico de barras usando os dados contados
qt_genus <- ggplot(cnt_genus, aes(x = reorder(genus, -Quantidade), y = Quantidade)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black") +  # gráfico de barras com contagem
  labs(x = "Genus", y = "Number of Estimates") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

# Calcular as contagens de cada familia
cnt_family <- banco_de_dados %>%
  group_by(family) %>%
  summarise(Quantidade = n()) %>%
  arrange(desc(Quantidade))  # Ordenar em ordem decrescente

# Criar o gráfico de barras usando os dados contados
qt_family <- ggplot(cnt_family, aes(x = reorder(family, -Quantidade), y = Quantidade)) +
  geom_bar(stat = "identity", fill = "lightgrey", color = "black") +  # gráfico de barras com contagem
  labs(x = "Families", y = "Number of Estimates") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

hist_logd <- ggplot(banco_de_dados, aes(x = Log10.D)) +
  geom_histogram(fill = "lightgrey", color = "black") +  # boxplot
  labs(x = "Density values", y = "Quantity") +  # rótulos dos eixos
  theme_minimal() +  # tema minimalista
  theme(axis.text.x = element_text(angle = 45, hjust = 1))  # ângulo das legendas do eixo X

print(hist_logd)

cnt_ndm <- banco_de_dados %>%
  group_by(new_detection_method) %>%
  summarise(Quantidade = n())

cnt_ndm <- cnt_ndm %>%
  mutate(porcentagem = (Quantidade/301) * 100)



ggsave("sempc/images/d_methods.png", plot = d_methods, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/d_environments.png", plot = d_environments, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/d_family.png", plot = d_family, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/qt_species.png", plot = qt_species, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/qt_family.png", plot = qt_family, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/qt_genus.png", plot = qt_genus, width = 6, height = 4, dpi = 300)

ggsave("sempc/images/hist_density_values.png", plot = hist_dnstvls, width = 6, height = 4, dpi = 300)

dados_log <- banco_de_dados$Log10.D

hist_dnstvls <- ggplot(data.frame(x = dados_log), aes(x = x)) +
  geom_histogram(binwidth = 0.1, fill = "lightgray", color = "black") +
  scale_x_continuous(
    breaks = log10(c(0.1, 1, 10)),  # Quebras em 0.1, 1, e 10
    labels = c(0.1, 1, 10)  # Rótulos deslogaritmados correspondentes
  ) +
  theme_minimal() +
  labs(x = "Density values", y = "Frequency")

